#!/bin/bash

service httpd status
